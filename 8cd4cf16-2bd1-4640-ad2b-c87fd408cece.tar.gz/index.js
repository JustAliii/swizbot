const Discord = require("discord.js");
const client = new Discord.Client();
const prefix = "s!";

client.on("ready" , ()=> {
    console.log('im online')
})
client.on("ready", () =>{
client.user.setActivity(prefix+"help | s!invite",{type:"PLAYING"})
console.log(`Logged in as ${client.user.tag}`)
}) 
client.on('message', natro => {
    if (natro.content === prefix + 'help') { 
  let embed = new Discord.MessageEmbed()    
  .setTitle(`🤖 | this Commands :`)  
  .setColor("#FF69B4")
  .setDescription(`
  Dashboard : https://swizbot.ga
   👥 | **Public Commands :**
  \`${prefix}ping\`
  \`${prefix}server\`
  \`${prefix}support\`
  \`${prefix}avatar\`
  \`${prefix}bot\`
  \`${prefix}youtube\`
  \`${prefix}servericon\`
  \`${prefix}banner\`
  \`${prefix}invites\`
  \`${prefix}discrim\`
    🥳 | **Fun Commands :**
  \`${prefix}iq\`
  \`${prefix}game\`
  \`${prefix}ask\`
  \`${prefix}rps\`
  \`${prefix}slap\`
  \`${prefix}roll\`
   ⚙ | **Admin Commands :**
  \`${prefix}setnick\`      
  \`${prefix}hide\`
  \`${prefix}show\`
  \`${prefix}clear\`
  \`${prefix}addemoji\`
  \`${prefix}lock\`
  \`${prefix}unlock\`
  \`${prefix}ban\`
  \`${prefix}unbanall\`
  \`${prefix}mute\`
  \`${prefix}unmute\`
  \`${prefix}kick\`
  \`${prefix}slow\`
  \`${prefix}emsay\`
  \`${prefix}vkick\`
  \`${prefix}removerole\`
  \`${prefix}here\`
  \`${prefix}everyone\`
  \`${prefix}role\`
  \`${prefix}pictureon\`
  \`${prefix}pictureoff\``)
  .setThumbnail(`${client.user.displayAvatarURL({ dynamic: true })}`) 
  .setFooter(`🛠 | Thx for using my cmd\nmy prefix = <${prefix}>`) 
  natro.channel.send(embed);  
    } 
});  
client.on("message",Baltra => {
    if(Baltra.content.startsWith(prefix + "user")){
  let embed = new Discord.MessageEmbed()
  .setColor("FF69B4")
  .setAuthor(Baltra.author.username,Baltra.author.avatarURL())
  .setThumbnail(Baltra.author.avatarURL())
  .setTitle("User Info :")
  
  
 .addField('**Name** :', ` ${Baltra.author.tag} `, true)
  
 .addField('**ID** :', ` ${Baltra.author.id} `, true)  
  
 .addField('**Created At** :', ` ${Baltra.author.createdAt.toLocaleString()} `, true)
  .setTimestamp(); 
  Baltra.channel.send(embed)
  }
  });
client.on("message", bader => {
  if(bader.content.startsWith(prefix + "ping"))
  bader.channel.send(`ping ${client.ws.ping}ms 📈`)
})
client.on('message', msg => {
if(msg.content == (prefix + "invite")) {
let embed = new Discord.MessageEmbed()
.setAuthor(`Requested by : ${msg.author.tag}` , msg.author.avatarURL({dynamic:true}))
.setTitle(`:arrow_right: Invite Me`)
.setURL(`https://discord.com/api/oauth2/authorize?client_id=${client. user.id}&permissions=0&scope=bot`)
.setTimestamp()
msg.channel.send(embed)
msg.react(`☑`)
}
})
client.on("message", RealPlus => {
  if (RealPlus.content === prefix + "server") {


    let embed = new Discord.MessageEmbed()
    .setTitle(`${RealPlus.guild.name}`)///RealPlus 
    .setThumbnail(client.user.avatarURL())
    .setColor('#3a6bff')///RealPlus 
    .setFooter(`Requested | ${RealPlus.author.tag}`, RealPlus.author.avatarURL())
    .addField('> 🆔   : ID Server :', `${RealPlus.guild.id}`)
    .addField('> :crown: Owner Server :', `${RealPlus.guild.owner}`)
    .addField('> :calendar: Created : ', `${RealPlus.guild.createdAt.toLocaleString()}`)
    .addField('> :busts_in_silhouette: Members : ', `${RealPlus.guild.memberCount}`)
    .addField('> :speech_balloon: Channels : ', `${RealPlus.guild.channels.cache.size}`)
    .addField('> :earth_americas: Region : ', `${RealPlus.guild.region}`)
    .setTimestamp()///RealPlus 
    RealPlus.channel.send(embed);
  }
});
 client.on("message", (hie) => {
    if (hie.content.startsWith(prefix + 'support')) {
        return hie.channel.send(
            new Discord.MessageEmbed()
            .setAuthor(hie.author.username, hie.author.avatarURL({ dynamic: true }))
            .setColor("FF69B4")
            .setThumbnail(hie.guild.iconURL({ dynamic: true }))
            .setTitle('CLick Here')
            .setURL(`https://discord.gg/29SKEmZzHh`)
            .setTimestamp()
            .setFooter(client.user.username, client.user.avatarURL({ dynamic: true }))
        )
    }
})
client.on("message", message => {
    if (message.content.startsWith(prefix + "setnick")) {
      if (!message.member.hasPermission("CHANGE_NICKNAME")) return message.reply("You Dont Have Permission")
      const args = message.content.slice(prefix.length).trim().split(/ +/g);
      let member = message.mentions.users.first() || message.guild.members.cache.get(args[1]) || message.guild.members.cache.find(r => r.user.username === args[1])
      if (!member) return message.reply(`Type User Example: ${prefix}setnick @user`)
      let nick = message.content.split(" ").slice(2).join(" ")
      let g = message.guild.members.cache.get(member.id)
      if (!nick) {
        g.setNickname(member.username)
      }
      g.setNickname(nick)
      const l = g.nickname || member.username
      let embed = new Discord.MessageEmbed()
        .setAuthor(message.member.user.username, message.member.user.avatarURL({ dynamic: true }))
        .setThumbnail(message.member.user.avatarURL({ dynamic: true }))
        .setTitle("New NickName:")
        .addField(`User Nick Change`, `${member}`, true)
        .addField(`Befor:`, `**${l}**`, true)
        .addField(`After:`, `**${nick}**`, true)


        .setFooter(message.member.user.username, message.member.user.avatarURL({ dynamic: true }))
        .setTimestamp()
      message.channel.send(embed)
    }
})
client.on("message",async message =>{
if (message.content.startsWith(prefix + 'hide')){
if (message.author.bot) return;
if (!message.member.hasPermission('MANAGE_CHANNELS')) return message.react('❌') 

if (!message.channel.guild) return;
message.channel.updateOverwrite(message.guild.id, {VIEW_CHANNEL: false})
message.react('✅').catch(err => console.log(`No perms to react`))
}
})
client.on("message",async message =>{
if (message.content.startsWith(prefix + 'show')){
if (message.author.bot) return;
if (!message.member.hasPermission('MANAGE_CHANNELS')) return message.react('❌') 
if (!message.channel.guild) return;
message.channel.updateOverwrite(message.guild.id, {VIEW_CHANNEL: true})
message.react('✅').catch(err => console.log(`No perms to react`))
}
})
client.on("message", ds => {
if(ds.content.startsWith(prefix + "avatar")){
if(ds.author.bot || ds.channel.type == "dm") return;
const nibo = ds.mentions.members.first() || ds.member;
var args = ds.content.split(" ").slice(1);
if(args == "server"){
   const embed = new Discord.MessageEmbed()
        .setAuthor(`SwizBot`)
.setDescription(`**Link as**\n[Server Avatar](${nibo.guild.iconURL({ dynamic: true })})`)
        .setColor("FF69B4")//color
        .setImage(nibo.guild.iconURL({ dynamic: true }))
        ds.channel.send(embed);
} else {
        const embed = new Discord.MessageEmbed()
        .setAuthor(`SwizBot`)
.setDescription(`**Link as**\n[Avatar Link](https://cdn.discordapp.com/avatars/${ds.author.id}/${ds.author.avatar}.gif)`)
        .setColor("FF69B4")//اختار اللون
        .setImage(nibo.user.avatarURL({ dynamic: true }))
        .setFooter('SwizBot')
        ds.channel.send(embed);
}
}
});
client.on("message", async msg => {
    if (msg.content.startsWith(prefix + "bot")) {
const m = await msg.channel.send("Bot's info !");
const bot = new Discord.MessageEmbed()
.setAuthor(client.user.username, client.user.displayAvatarURL({ format : 'png' , dynamic: true, size: 2048 }))
.setFooter(`Requested By ${msg.author.tag}`, msg.author.displayAvatarURL({  dynamic: true, size: 2048 }))
.setTimestamp()
.setColor("FF69B4")
.addField(`🚀 ⊢Bot Name`, `**${client.user.tag}**`, true)
.addField(`🆔 ⊢Bot ID`, `${client.user.id}`, true)
.addField(`👑 ⊢Bot Owner`, `<@921764515320836117>`, true)
.addField(`📶 ⊢Bot Ping`, `\`${m.createdTimestamp - msg.createdTimestamp}ms\`\n Uptime : \`${client.uptime}\``, true)
.addField(`📒 ⊢Library`,`Discord.js\nnode.js-javascript`, true)
.addField(`📉 ⊢Memory Usage`,`RSS : \`\`${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB\`\`\n Heap : \`\`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\`\``, true)
.addField(`📌 ⊢Guilds Size`, `${client.guilds.cache.size}`, true)
.addField(`👥 ⊢Users Size`, `${client.users.cache.size}`, true)
.addField(`💬 ⊢Channels Size`, `${client.channels.cache.size}`, true)


m.edit(bot)
}
});
client.on("message", async message => {
    let command = message.content.toLowerCase().split(" ")[0];
    command = command.slice(prefix.length);
    if (command == "clear" || command == "مسح") {
        message.delete({ timeout: 0 })
        if (!message.channel.guild) return message.reply(`** This Command For Servers Only**`);
        if (!message.member.hasPermission('MANAGE_GUILD')) return message.channel.send(`> ** You don't have perms ❌**`);
        if (!message.guild.member(client.user).hasPermission('MANAGE_GUILD')) return message.channel.send(`> ** I don't have perms ❌**`);
        let args = message.content.split(" ").slice(1)
        let messagecount = parseInt(args);
        if (args > 100) return message.channel.send(
            new Discord.MessageEmbed()
            .setDescription(`\`\`\`js
i cant delete more than 100 messages 
\`\`\``)
        ).then(messages => messages.delete({ timeout: 5000 }))
        if (!messagecount) messagecount = '100';
        message.channel.messages.fetch({ limit: 100 }).then(messages => message.channel.bulkDelete(messagecount)).then(msgs => {
            message.channel.send(
                    (`**${msgs.size} Messages Cleared   🗑 **
`)
            ).then(messages =>
                messages.delete({ timeout: 5000 }));
        })
    }
});
client.on("message", message => {
  if (!message.content.startsWith(prefix) || message.author.bot) return;
  const args = message.content.slice(prefix.length).trim().split(' ');
  const command = args.shift().toLowerCase();
if(command === "youtube"){
    message.channel.send(
      new Discord.MessageEmbed()
      .setThumbnail(client.user.avatarURL())
.setColor("GREEN")
      .setTitle('Your Search for youtube')
      .setURL(`https://m.youtube.com/results?sp=mAEA&search_query=${args}`)
    );
  }
});
client.on("message", msg => {
    var args = msg.content.split(" ");
    var command = args[0];
    var emojisname = args[1];
    var emojislink = args[2];
    if (command === prefix + "addemoji") {
        if (!msg.guild){
            return msg.channel.send("Only SERVER Commands");
        }
        if (!msg.guild.member(client.user).hasPermission("MANAGE_EMOJIS")){
            return msg.channel.send("Bot Doesnt have Administration  `MANAGE_EMOJIS`");
        }
        if(!msg.guild.member(msg.author).hasPermission("MANAGE_EMOJIS")) {
            return msg.channel.send("You Don't have administration `MANAGE_EMOJIS`");
        }
        if(!emojisname){
            return msg.channel.send("Enter a name for emoji");
        }
        if (!emojislink){
            return msg.channel.send("Enter emoji link");
        }
        msg.guild.emojis.create(emojislink, emojisname).then(emoji =>{
            msg.channel.send("Emoji Created . <:"+emoji.name+":"+emoji.id+">")
        }).catch(err => msg.channel.send("Image size must be less than `256` KB"));
    }

});
client.on('message', nibo => {
  if (nibo.content === prefix + "servericon") {
    const embed = new Discord.MessageEmbed()
.setTitle(`Server Avatar`)
.setFooter(nibo.guild.name)
.setImage(nibo.guild.iconURL())
.setColor("FF69B4")//اللون 
nibo.channel.send(embed);
}});
client.on("message", message => {
    if (message.content.includes("Fuck") || message.content.includes("Fuck you"))
        message.delete();
});
client.on("message", message => {
if(message.content.startsWith(prefix + "banner")){
  const args = message.content.slice(" ").trim().split(/ +/);
  let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
  if(!user){
let mishoo1 = new Discord.MessageEmbed()
.setImage(`https://api.abderrahmane300.repl.co/banner/${message.author.id}`)
  message.channel.send(mishoo1)
} if(user){
if(user.user.bot) return message.channel.send("Bots not Have banners :(")
let mishoo = new Discord.MessageEmbed()
.setImage(`https://api.abderrahmane300.repl.co/banner/${user.id}`)
message.channel.send(mishoo);
}      
}
})
client.on('guildCreate', moriano => {
  const channel = moriano.channels.cache.find(channel => channel.type === 'text' && channel.permissionsFor(moriano.me).has('SEND_MESSAGES'))
  channel.send("Thanks For Adding SwizBot To Your Server <3")
})
client.on('message', message => {
  if(message.author.bot)return;
  if (message.content.startsWith(prefix + 'طرد') || message.content.startsWith(prefix + 'kick')) {
        if (!message.guild.member(message.author).hasPermission("KICK_MEMBERS"))
      return message.reply("**You Don't Have ` KICK_MEMBERS ` Permission**");
    if (!message.guild.member(client.user).hasPermission("KICK_MEMBERS"))
      return message.reply("**I Don't Have ` KICK_MEMBERS ` Permission**");      
    const user = message.mentions.users.first();
    if (user) {
      const member = message.guild.member(user);
      if (member) {
        member
          .kick({
            reason: "No reason",
          })
          .then(() => {
           const embed = new Discord.MessageEmbed()
           .setColor("#FF69B4")
          .setTitle(`**✅ ${user.tag} kicked from the server! ✈️**`)
          message.channel.send(embed);
          })
          .catch(err => {
            message.reply(`🙄 - I couldn't kick that user. Please check my permissions and role position.`);
            console.error(err);
          });
      } else {
        message.reply(`**🙄 - I can't find <@847789179294842880> in the ban list**`);
      }
    } else {
const embed = new Discord.MessageEmbed()
.setColor("#FF69B4")
.setTitle("**Command: Kick**")
.setDescription(`
Kick a member.
 
**Usage:**
${prefix}kick (user) (reason)
 
**Examples:**
${prefix}kick ${message.author}
${prefix}kick ${message.author} spamming`)
message.channel.send(embed);
    }
  }
});
client.on('message', async normal => {
  if (normal.content.startsWith(prefix + "ban")){
        if(!normal.member.hasPermission('BAN_MEMBERS')) return normal.channel.send("You don't have permissions")
           if(!normal.guild.me.hasPermission('BAN_MEMBERS')) return normal.channel.send("I don't have permissions")
         const args = normal.content.slice(prefix.length).trim().split(/ +/g);
        var member = normal.mentions.members.first()||normal.guild.members.cache.get(args[1])||normal.guild.members.cache.find(m => m.user.username === args.slice(1).join(' '));
                if(!member) return normal.channel.send(`**Please Mention user or Type the user ID/Username ${args.slice(1).join(' ')} **`)
                if (member.id === normal.author.id)return normal.reply(`**You can't ban yourself**`)
      if (member.id === normal.guild.me.id)return normal.reply(`**You can't ban me dumbass**`)
                     if(!member.bannable) return normal.channel.send(`**The member role is higher than me**`);

         await member.ban({reason:`He/She just got bannned`})
        normal.channel.send(`**${member.user.username} Has been BANNNED ✈**`)
    } 
})
client.on('message', async normal => {
  if (normal.content.startsWith(prefix + "mute")){
        if(!normal.member.hasPermission('MANAGE_ROLES')) return normal.channel.send("You don't have permissions")
         const args = normal.content.slice(prefix.length).trim().split(/ +/g);
        var member = normal.mentions.members.first()||normal.guild.members.cache.get(args[1])||normal.guild.members.cache.find(m => m.user.username === args.slice(1).join(' '));
                if(!member) return normal.channel.send(`**Please Mention user or Type the user ID/Username ${args.slice(1).join(' ')} **`)
                if (member.id === normal.author.id)return normal.reply(`**You can't mute yourself**`)
      if (member.id === normal.guild.me.id)return normal.reply(`**You can't mute me dumbass**`)
        let mutedrole = normal.guild.roles.cache.find(ro => ro.name === 'muted')
        if(!mutedrole) {
        try {
        var createdrole = await normal.guild.roles.create({
                      data : {
                        name : 'muted',
                        permissions: [],
                    }});
                        normal.guild.channels.cache.forEach(async (channel, id) => {
                            await channel.createOverwrite(createdrole, {
                                SEND_MESSAGES: false,
                                ADD_REACTIONS : false
                            })
                        })
                } catch (err) {
                console.log(err)
            }};
let muterole = normal.guild.roles.cache.find(r => r.name === 'muted')
         member.roles.add(muterole)
        normal.channel.send(`**${member.user.username} Has been muted**`)
    } 
})
client.on('message', async normal => {
  if (normal.content.startsWith(prefix + "unmute")){
    var args = normal.content.slice(prefix.length).trim().split(/ +/g);
        if(!normal.member.hasPermission('MANAGE_ROLES')) return normal.channel.send("You don't have permissions");
        var member = normal.mentions.members.first()||normal.guild.members.cache.get(args[1])||normal.guild.members.cache.find(m => m.user.username === args.slice(1).join(' '));
                     if(!member) return normal.channel.send(`**Please Mention user or Type the user ID/Username **`)
                let muterole = normal.guild.roles.cache.find(r => r.name === 'muted')
        if(!member.roles.cache.has(muterole.id))return normal.channel.send(`**${member.user.username} is not muted**`)
        await member.roles.remove(muterole);
        normal.channel.send(`**${member.user.username} Has been unmuted**`)
  }})
client.on('message', badboy => {
  if(badboy.content.startsWith(prefix + "iq")){
    const iq = [
'5',
'6',
'10',
'17',
'20',
'15',
'24',
'30',
'35',
'40',
'43',
'45',
'50',
'55',
'60',
'75',
'85',
'90',
'99',
'100',
    ];
                let an = iq[Math.floor(Math.random() * iq.length)];
                var embed = new Discord.MessageEmbed()
.setDescription(`${badboy.author.username} your iq has ${an}`)
.setColor("FF69B4")
.setFooter(`Requsted By ${badboy.author.tag}`, badboy.author.avatarURL({dynamic : true}))
.setThumbnail(`${badboy.guild.iconURL({dynamic : true})}`)
badboy.channel.send(embed)
  }
})
client.on('message', badboy => {
  if(badboy.content.startsWith(prefix + "game")){
let args = badboy.content.split(" ").slice(0);
var user = badboy.mentions.users.first() || badboy.author;
    if (user.bot || !badboy.guild) return;

 if(badboy.author.bot || !badboy.guild) return badboy.reply("this command for server only")
let win = [
 ':upside_down: :upside_down: :upside_down:  win',
 ':upside_down: :face_with_raised_eyebrow: :zany_face: lose',
 ':upside_down: :face_with_raised_eyebrow: :upside_down: lose',
 ' :yum: :yum: :yum: win',
 ' :kissing_heart:  :kissing_heart:  :kissing_heart:  win', 
 ' :frowning2: :frowning2: :kissing_heart: lose',
 
  ];
            
            let an = win[Math.floor(Math.random() * win.length)];

  var embed = new Discord.MessageEmbed()
  .setColor("FF69B4")
  .setDescription(`${an}`)
 badboy.channel.send(embed)
  }

})
client.on('message', message => {
  var args = message.content.split(/[ ]+/)
  if(message.content.includes('discord.gg')){
    if(!message.member.hasPermission('ADMINISTRATOR'))
      message.delete()

  }
});
client.on("message", message => {
  if(message.content.startsWith(prefix + "slow")){
    let args = message.content.split(" ").slice(1).join(" ")
    let perm = "ADMINISTRATOR"
    if(!args) return message.channel.send('**Enter a number ! **')
    if(!message.member.hasPermission(perm)) return message.channel.send(`You Don't Have \`${perm}\` `)
    message.channel.setRateLimitPerUser(args)
  }})
let rg = [
"**What is your name ?**",
"**How old are you ?**",
"**Where are you from ?**",
"**What do you do in life? Away from Discord ?**",
"**How long have you been in the server ?**",
"**Do you have an idea for programming ?**",
"**What is your specialty ?**",
"**What do you want to be in the future ? **",
"**Do you give confidence to anyone ?**",
"**Do you have an idea about the owner of the server ?**",
"**How long have you been on Discord ?**",
]
client.on("message", msg => {
  if (msg.content.startsWith(prefix + "ask")) {
    let rg1 = new Discord.MessageEmbed()
      .setDescription(rg[Math.floor(Math.random() * rg.length)] )
      .setColor("FF69B4")
     
    msg.channel.send(rg1)
  }
  
})
client.on("message", message => {
  if(message.content.startsWith( prefix + 'role')){
    if(!message.member.hasPermission('MANAGE_ROLES')) return message.react(`❌`)
let role = message.mentions.roles.first()


if(!role) return message.reply(`Please Mention The User And Role After Command !`)
    let member = message.guild.member(message.mentions.users.first())
    if(!member) return message.reply(`Please Mention The User`)
message.reply(`Done!`)
member.roles.add(role)
    

  }
})
client.on("message", msg => {
    let moonlight = msg.content.split(" ").slice('1').join(" ")
    if (msg.author.bot) return;
    if (msg.content.startsWith(prefix + 'emsay')) {
      if (!msg.member.hasPermission('ADMINISTRATOR'))
        return msg.channel.send('Permission required! "ADMINISTRATOR"')
      msg.delete()
      let moonlight1 = new Discord.MessageEmbed()
        .setColor('#FF69B4	')
        .setFooter(`Request by ${msg.author.tag}` , msg.author.avatarURL({dynamic:true})).setTimestamp()
        .setDescription(`${moonlight}`)
      msg.channel.send(moonlight1)

    }
});
client.on("message", msg => {
  if (
    msg.content == prefix + "roll"
  ) {
    if (msg.author.bot) return;
    if (msg.channel.type == "dm") return msg.channel.send(new Discord.MessageEmbed().setColor("FF69B4").setDescription(error + ` **You Can't Use This Command In DM's!**`).setFooter(`Request By ${msg.author.tag}`).setTimestamp())

    var x = ["0", "0", "0", "3", "14", "7", "5", "52", "83", "72", "89", "15", "68", "72", "45", "35", "26", "39", "41", "52", "61", "69", "73", "81", "97", "100"];
    var x3 = Math.floor(Math.random() * x.length);
    msg.channel.send(`${x[x3]}`)
  }
})
client.on('message', msg => {
  if (msg.content.split(' ')[0].toLowerCase() == prefix + 'invites') {
    let guild = msg.guild
    var codes = [""]
    var nul = 0

    guild.fetchInvites()
      .then(invites => {
        invites.forEach(invite => {
          if (invite.inviter === msg.author) {
            nul += invite.uses
            codes.push(`discord.gg/${invite.code}`)
          }

        })
        if (nul > 0) {
          const e = new Discord.MessageEmbed()
            .addField(`${msg.author.username}`, `You Have invited **${nul}** To this server `)
            .setColor("FF69B4")
          msg.channel.send(e)
        } else {
          var embed = new Discord.MessageEmbed()
            .setColor("FF69B4")
            .addField(`${msg.author.username}`, `You have not invited anyone to this server`)

          msg.channel.send({ embed: embed });
          return;
        }
      })
  }
})
client.on ('guildCreate', async Guild => {
    let Invite = await Guild.channels.cache.first ().createInvite ({ maxAge: 0 });
    let Channel = await client.channels.fetch ('845563483109195785');//إيدي الشات
    Channel.send ('**Im Joined This server :**\n' + Guild.name + '\n' + Invite.url);//الكلام عند الدخول
});
//ismailmgde
//خروج البوت
client.on ('guildDelete', async Guild => {
    let Channel = await client.channels.fetch ('925361509155086401');//ايدي الشات
    Channel.send ('**Im Out This server :**\n' + Guild.name);//الكلام بعد الخروج
});
client.on("guildMemberAdd", async(member) => {
    if(!member.guild)return ;
    const fetchedlog = await member.guild.fetchAuditLogs({
        limit: 1,
        type: "BOT_ADD"
    })
    const dedect = fetchedlog.entries.first()
    const logchannel = client.channels.cache.get("925361509155086398")
    if(!dedect) return logchannel.send(`Some One Add ${member.user.tag} Without One Know`);
    const { executor , target } = dedect
    if(target.id === member.id) {
        if(executor.bot) {
            logchannel.send(
                `\`Bot Invite\`\nBot Name: \`${executor.tag}\`\nBy: ${target.tag}`
            )
        }
    }
})
client.on('message', async message => {
  if(!message.content.startsWith(prefix) || message.author.bot) return;
  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if(command === 'removerole') {
    
    let role = await message.mentions.roles.first() || await message.guild.roles.cache.get(args[0]);

    if(!role) return await message.channel.send('Please Mention The user and role after the command !');

    try {
    await message.guild.members.cache.forEach(member => {member.roles.remove(role)});
    await message.channel.send(`Done ✅`);
    } catch (err) {
      await message.channel.send(`Erorr : ${err}`)
    }
  }
});
client.on('message', message => {
    if (message.content.startsWith("s!lock")) {
        if (!message.member.hasPermission("MANAGE_CHANNELS")) return
        let everyone = message.guild.roles.cache.find(m => m.name === '@everyone');
        message.channel.createOverwrite(everyone, {
            SEND_MESSAGES: false,
        })
        message.channel.send("**Room Locked 🔒** ");
    }
 });
client.on('message', message => {
    if (message.content.startsWith("s!unlock")) {
        if (!message.member.hasPermission("MANAGE_CHANNELS")) return
        let everyone = message.guild.roles.cache.find(m => m.name === '@everyone');
        message.channel.createOverwrite(everyone, {
            SEND_MESSAGES: true,
        })
        message.channel.send(" **Room Unlocked 🔓**  ")
    }
}); //unlock
client.on('message', badboy => {
  if(badboy.content.startsWith(prefix + "feedback")){
    const args = badboy.content.split(" ").slice(1).join(" ")
    if(!args) return badboy.channel.send("Write your feedback !")
    var fedbackchannel = badboy.guild.channels.cache.find(channel => channel.name === "📧・feedback"); //اسم الروم

    const embed = new Discord.MessageEmbed()
    .setTitle("New Feedback")
    .setColor("#FF69B4	")
    .setThumbnail(`${badboy.author.avatarURL({dynamic : true})}`)
    .setDescription(`${args}`)
    .setFooter("THX FOR YOUR FEEDBACK ❤")
    badboy.channel.send("Thanks For Your Feedback <3")
fedbackchannel.send(embed).then(badboy => {
  badboy.react("❤")
})
  }
});
client.on('ready', async() => {
        client.channels.cache.get('925361509155086398').send("Im Online Now !")
        client.channels.cache.get('925361508916031569').join()
        console.log("Hello Im Online")
});
client.on("message", message => {
        switch(message.content.toLowerCase()) {
            case (prefix + "unbanall"):
                if (message.member.hasPermission("ADMINISTRATOR")) {
                    message.guild.fetchBans().then(bans => {
                        if (bans.size == 0) {message.reply("There are no banned users !"); throw "No members to unban."};
                        bans.forEach(ban => {
                            message.guild.members.unban(ban.user.id);
                        });
                    }).then(() => message.reply(" Done All Users Unbaned !")).catch(e => console.log(e))
                } else {message.reply("You do not have enough permissions for this command.")}
            break;
        }
      });
client.on('message', message => {
    if (message.content.startsWith(prefix + 'here')) {
        if (!message.member.hasPermission('ADMINISTRATOR')) return
        if (message.author.bot) return
        message.channel.send(`@here`)
}
})
client.on('message', message => {
    if (message.content.startsWith(prefix + 'everyone')) {
        if (!message.member.hasPermission('ADMINISTRATOR')) return
        if (message.author.bot) return
        message.channel.send(`@everyone`)
}
})
client.on('message', async message => {
    if (message.content.startsWith(prefix + 'pictureoff')) {
        if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.channel.send(`** You do not have permission to use the command ! 🙄 **`);
        let channel = message.mentions.channels.first();
        let channel_find = message.guild.channels.cache.find(ch => ch.id == channel);
        if (!channel) channel_find = message.channel
        if (!channel_find) return;
        channel_find.updateOverwrite(message.guild.id, {
            ATTACH_FILES: false
        });
        message.channel.send(`\n🌌 | Picture Not Allowed In <#${channel_find.id}>\n`);
      
    }
});
client.on('message', async message => {
    if (message.content.startsWith(prefix + 'pictureon')) {
        if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.channel.send(`**  You do not have permission to use the command ! 🙄 **`);
        let channel = message.mentions.channels.first();
        let channel_find = message.guild.channels.cache.find(ch => ch.id == channel);
        if (!channel) channel_find = message.channel;
        if (!channel_find) return;
        channel_find.updateOverwrite(message.guild.id, {
            ATTACH_FILES: true
        });
        message.channel.send(`\n🌌 | Picture Allowed In  <#${channel_find.id}>\n`);
    }
});
client.on('message', layer => {
  if (layer.content.startsWith(prefix + "slap")) {
    var user1 = layer.mentions.members.first()
    var user2 = layer.author
    if (!user1) return layer.channel.send("** Plese mention someone to slap.**");
 if (user1.id == layer.author.id) return layer.channel.send("**You cannot slap yourself**")
    let embed = new Discord.MessageEmbed()
    .setDescription(`**    ${user1} are slaped By ${user2}**`)
    .setColor("##FF69B4")
    .setFooter(`Requested by ${layer.author.tag}`, `${layer.author.avatarURL({dynamic : true})}`)
    .setImage(`https://cdn.discordapp.com/attachments/801526558464409691/816389676750340127/Li9mx3A.gif`)
    layer.channel.send(embed)
  }
});
client.on('message', message => {
    if (message.content.startsWith(prefix + 'discrim')) {
var di = message.mentions.users.first()||message.author
    var users = client.users.cache.filter(user => user.discriminator === di.discriminator).map(m => m.tag);
            message.channel.send(new Discord.MessageEmbed()
            .setTitle(`${users.length} users found with the #${di.discriminator} discriminator`)
            .setDescription(`\`\`\`
            ${users}\`\`\``)
            .setAuthor(`${di.username}`)
           .setColor("##FF69B4")
            .setThumbnail(`${di.displayAvatarURL()}`)
            )
        .catch(err => {
            console.error(err)
        });
}})
client.on('message', async badboy => {
  if(badboy.content.startsWith(prefix + "vkick")){
    if(!badboy.member.hasPermission("MOVE_MEMBERS")) return 
              if (!badboy.channel.guild) return badboy.channel.send('This is for servers only');

 let user = badboy.guild.member(
        badboy.mentions.users.first())

        if(!user) return badboy.channel.send("Mention Some One")
         if (!badboy.guild.member(user).voice.channel) return badboy.channel.send("This user not in a voice")
    await user.voice.kick()
badboy.channel.send(` ${user} Has been kicked from the voice`)
  }
})
client.on('message', message => {
if (message.content.startsWith(prefix + "sug")) {
if (!message.channel.guild) return;
var roomid = "925361508731465776";// Suggestion room id
var room = client.channels.cache.get(roomid);
  if (!room) return undefined;
let sug = message.content.split(" ").slice(1).join(" ");
var embed = new Discord.MessageEmbed()
 .setColor("#FF69B4")
 .setAuthor(message.author.username, message.author.displayAvatarURL())
 .addField(`✅ **New Suggestion :**`,`\`\`\`apache
${sug}\`\`\``)
 .setFooter(`${message.author.username}`)
 .setThumbnail(message.author.displayAvatarURL())
 .setTimestamp();
  message.react("✅")
  room.send(embed).then(c => {
  c.react('✅').then(() =>
  c.react('❌'))
  })
 }
});
client.on("message", async function(message) {

  if (message.content.startsWith(prefix + "rps")) {
    let messageArgs = message.content
      .split(" ")
      .slice(1)
      .join(" ");
    let messageRPS = message.content
      .split(" ")
      .slice(2)
      .join(" ");
    let arrayRPS = ["**# - Rock**", "**# - Paper**", "**# - Scissors**"];
    let result = `${arrayRPS[Math.floor(Math.random() * arrayRPS.length)]}`;
    var RpsEmbed = new Discord.MessageEmbed()
      .setAuthor(message.author.username)
      .setThumbnail(message.author.avatarURL)
      .setColor("#FF69B4")
      .addField("Rock", "🇷", true)
      .addField("Paper", "🇵", true)
      .addField("Scissors", "🇸", true);
    message.channel.send(RpsEmbed).then(msg => {
      msg.react("🇸");
      msg.react("🇷");
      msg
        .react("🇵")
        .then(() => msg.react("🇸"))
        .then(() => msg.react("🇷"))
        .then(() => msg.react("🇵"));
      let reaction1Filter = (reaction, user) =>
        reaction.emoji.name === "🇸" && user.id === message.author.id;
      let reaction2Filter = (reaction, user) =>
        reaction.emoji.name === "🇷" && user.id === message.author.id;
      let reaction3Filter = (reaction, user) =>
        reaction.emoji.name === "🇵" && user.id === message.author.id;
      let reaction1 = msg.createReactionCollector(reaction1Filter, {
        time: 12000
      });

      let reaction2 = msg.createReactionCollector(reaction2Filter, {
        time: 12000
      });
      let reaction3 = msg.createReactionCollector(reaction3Filter, {
        time: 12000
      });
      reaction1.on("collect", r => {
        message.channel.send(result);
      });
      reaction2.on("collect", r => {
        message.channel.send(result);
      });
      reaction3.on("collect", r => {
        message.channel.send(result);
      });
    });
  }
});

client.login('OTI1NzA1NTY2NjM3MTU0MzA0.YcxAfQ.G4nI5ojJfKDR0c0ELST1jRf9zg0');